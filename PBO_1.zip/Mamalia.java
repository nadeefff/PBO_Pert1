/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class Mamalia extends Hewan {
    private String jenisRambut;
    private String ukuranTubuh;

    public String getJenisRambut() {
        return jenisRambut;
    }

    public void setJenisRambut(String jenisRambut) {
        this.jenisRambut = jenisRambut;
    }

    public String getUkuranTubuh() {
        return ukuranTubuh;
    }

    public void setUkuranTubuh(String ukuranTubuh) {
        this.ukuranTubuh = ukuranTubuh;
    }
    }