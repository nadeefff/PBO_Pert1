/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class Reptil extends Hewan {
     private String jenisKulit;
     private String habitat;

     public void setJenisKulit(String jenisKulit) {
         this.jenisKulit = jenisKulit;
     }
     public String getJenisKulit() {
        return jenisKulit;
     }
     public void setHabitat(String habitat) {
        this.habitat = habitat;
    }
    public String getHabitat() {
        return habitat;
    }
    }