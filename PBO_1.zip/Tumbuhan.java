/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class Tumbuhan extends MakhlukHidup {
    private String warnaDaun;
    private String arahDaun;

    public void setWarnaDaun(String warna) {
        this.warnaDaun = warna;
    }
    public String getWarnaDaun() {
        return this.warnaDaun;
    }
    public void setArahDaun(String arah) {
        this.arahDaun = arah;
    }

    public String getArahDaun() {
        return this.arahDaun;
    }

}