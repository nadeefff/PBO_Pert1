/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class Aves extends Hewan {
    private String warnaBulu;
    private String jenisParuh;
 
    public void setWarnaBulu(String warnaBulu) {
        this.warnaBulu = warnaBulu;
    }
    public String getWarnaBulu() {
        return warnaBulu;   
    }
    public void setJenisParuh(String jenisParuh) {
        this.jenisParuh = jenisParuh;
    }
    public String getJenisParuh() {
        return jenisParuh;
    }
}