/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class Utama {
    public static void main(String[] args){
        Hewan rawr = new Hewan();
        System.out.println("Nama saya rawr:");
        rawr.bernafas();
        rawr.tumbuh();
        
        Tumbuhan pepaya = new Tumbuhan();
        System.out.println("");
        System.out.println("Nama saya pepaya");
        pepaya.setWarnaDaun("Hijau");
        pepaya.setArahDaun("Barat");
        pepaya.bernafas();
        pepaya.tumbuh();
        System.out.println("Arah daun pagi hari" +pepaya.getArahDaun());
        System.out.println("Warna daun" +pepaya.getWarnaDaun());
        
        Dikotil mangga = new Dikotil();
        System.out.println("");
        System.out.println("Nama saya mangga");
        mangga.setWarnaDaun("Hijau");
        mangga.setArahDaun("Barat");
        mangga.setCaraBerkembangbiak("Biji");
        mangga.bernafas();
        mangga.tumbuh();
        System.out.println("Cara Berkembangbiak" +mangga.getCaraBerkembangbiak());
        System.out.println("Arah daun pagi hari" +mangga.getArahDaun());
        System.out.println("Warna daun" +mangga.getWarnaDaun());
        
        Monokotil padi = new Monokotil();
        System.out.println("");
        System.out.println("Nama saya padi");
        padi.setWarnaDaun("Hijau");
        padi.setArahDaun("Timur");
        padi.setKondisiTumbuh("Daerah panas curah hujan tinggi");
        mangga.bernafas();
        mangga.tumbuh();
        System.out.println("Cara Berkembangbiak" +mangga.getCaraBerkembangbiak());
        System.out.println("Arah daun pagi hari" +mangga.getArahDaun());
        System.out.println("Warna daun" +mangga.getWarnaDaun());
       
     
        
        Reptil ular = new Reptil();
        System.out.println("");
        System.out.println("Nama saya ular");
        ular.bernafas();
        ular.tumbuh();
        ular.setHabitat("Darat");
        ular.setJenisKulit("Bersisik");
        ular.setJumlahKaki(0);
        System.out.println("Jumlah kaki ular "+ String.valueOf(ular.getJumlahKaki()));
        System.out.println("Jenis Kulit: " + ular.getJenisKulit());
        System.out.println("Habitat: " + ular.getHabitat());
        
        Mamalia harimau = new Mamalia();
        System.out.println("");
        System.out.println("Nama saya harimau");
        harimau.tumbuh();
        harimau.bernafas();
        harimau.setJumlahKaki(4);
        System.out.println("Jumlah kaki harimau "+ String.valueOf(harimau.getJumlahKaki()));
        harimau.setJenisRambut("Tebal");
        harimau.setUkuranTubuh("Besar");
        System.out.println("Jenis Rambut: " + harimau.getJenisRambut());
        System.out.println("Ukuran Tubuh: " + harimau.getUkuranTubuh());
        
        Aves lovebird = new Aves();
        System.out.println("");
        System.out.println("Nama saya Aves");
        lovebird.tumbuh();
        lovebird.bernafas();
        lovebird.setJumlahKaki(4);
        System.out.println("Jumlah kaki lovebird "+ String.valueOf(lovebird.getJumlahKaki()));
        lovebird.setJenisParuh("PemakanBiji");
        lovebird.setWarnaBulu("Hijau");
        System.out.println("Warna Bulu: " + lovebird.getWarnaBulu());
        System.out.println("Jenis Paruh: " + lovebird.getJenisParuh());
        
        Insect kupukupu = new Insect();
        System.out.println("");
        System.out.println("Nama saya insect");
        kupukupu.tumbuh();
        kupukupu.bernafas();
        kupukupu.setJumlahKaki(4);
        System.out.println("Jumlah kaki kupukupu "+ String.valueOf(kupukupu.getJumlahKaki()));
        kupukupu.setJenisSayap("Dua Pasang Sayap bersisik");
        System.out.println("JenisSayap: " + kupukupu.getJenisSayap());
        
        Amphibi katak = new Amphibi();
        System.out.println("");
        System.out.println("Nama saya Amphibi");
        katak.tumbuh();
        katak.bernafas();
        katak.setJumlahKaki(4);
        System.out.println("Jumlah kaki katak "+ String.valueOf(katak.getJumlahKaki()));
        katak.setLingkungan("hidup di 2 alam");
        katak.setSuhuLingkungan("Suhu Dingin");
        System.out.println("Lingkungan " + katak.getLingkungan());
        System.out.println("Suhu Lingkungan: " +katak.getSuhuLingkungan());
    }   
    }