/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LENOVO
 */
public class Amphibi extends Hewan {
    private String lingkungan;
    private String suhuLingkungan;

    public void setLingkungan(String lingkungan) {
        this.lingkungan = lingkungan;
    }
    public String getLingkungan() {
        return lingkungan;
    }
    public void setSuhuLingkungan(String suhuLingkungan) {
        this.suhuLingkungan = suhuLingkungan;
    }
    public String getSuhuLingkungan() {
        return suhuLingkungan;
    }
    }
